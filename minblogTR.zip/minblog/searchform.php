<!--- Search form --->
<form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>"
    <div class="input-group">
  <input type="text" class="form-control" name="s" id="s" placeholder="Bir şeyler yaz..." aria-describedby="basic-addon2">
  <div class="input-group-append">
    <button class="btn btn-dark" id="searchsubmit" type="submit"><i class="fa fa-search"></i></button>
  </div>
</div>

</form>