<?php get_header(); ?>

  <!--- 404 --->
  <div class="row text-center">

      <div class="col-md-12">
        <!--- 404 title--->
        <p class="no-text text-center">404</p>
        <h3 class="card-subtitle mb-4">Sayfa Bulunamadı</h3>
        <!--- 404 search form --->
        <p>Maalesef aradığınız sayfayı bulamadık, belki de arama yapmalısınız.</p>
        <?php get_search_form(); ?>
     
      </div>

      </div>

  </div>

  </div>

<?php get_footer(); ?>