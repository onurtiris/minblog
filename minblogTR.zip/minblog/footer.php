</main><!-- /.container -->

<!--- Footer --->
<footer class="footer mt-auto py-3">
  <!--- Footer text --->
  <div class="container text-light">
    <a>Copyright &copy; <?php echo date("Y"); echo " "; ?><a class="orange" href="<?php echo get_site_url(); ?>"><?php echo bloginfo('name'); ?></a><a href="https://www.behance.net/onurtiris"> | minBlog Theme</a></a>
  </div>
</footer>

<?php wp_footer(); ?>

</body>
</html>